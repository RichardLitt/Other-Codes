This is a chrome extension to get rid of the distracting bits of
Facebook, while still allowing you to talk to the few friends you were
already talking to. Optionally, you can include the list of friends
online - personally, I'd rather not. 

To install, download drought.zip. Unpack it. Go to chrome://extensions
in the browser, and click "Load unpacked extensions...". Enable or
disable as desired. Go to Facebook. Press refresh. Enjoy. 
