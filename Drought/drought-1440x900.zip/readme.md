This is a Chrome extension to get rid of the distracting bits of
Facebook, while still allowing you to talk to the few friends you were
already talking to. Optionally, you can include the list of friends
online, by hiding the Facebook chat bar (clicking in the lower right
corner.) Or you can comment out the code, if you're keen on js.  

To install, download drought.zip. I have a 13" Macbook - 1220x800. You
might have a 15" - get the 1440x900 version, in that case. Unpack it. Go to chrome://extensions
in the browser, and click "Load unpacked extensions...". Enable or
disable as desired. Go to Facebook. Press refresh. Enjoy. 
